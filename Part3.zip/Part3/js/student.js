$(document).ready(function () {
		        console.log("welcome");
            <!-- alert("welcome"); -->
			
			$("#btnSave").click(function()
			{
			  console.log("Student Name is  : " +$("#txtName").val());
			    console.log("Student Address  is: " +$("#txtAddress").val());
			});
			
});

 